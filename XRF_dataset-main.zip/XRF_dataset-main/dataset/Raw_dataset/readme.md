This folder is used to save datasets downloaded by Kaggle
