This folder is used to save the training sets and datasets that have been split_train_test.py and generate_txt.py and then segmented, as well as the corresponding label files
