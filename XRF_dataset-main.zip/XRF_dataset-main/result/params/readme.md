Save the network parameters for the last 10 epochs of each training session
