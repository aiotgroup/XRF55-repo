Save network training accuracy, loss, and other parameters
