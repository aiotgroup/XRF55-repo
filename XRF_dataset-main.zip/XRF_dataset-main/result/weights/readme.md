Save the network parameter weights and classification results as a file
