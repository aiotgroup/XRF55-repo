This repo hosts the supplementary utilities, firmware, etc., needed for the
Linux 802.11n CSI Tool.  See the [project
website](http://dhalperi.github.com/linux-80211n-csitool/) for more info.

**License:**
See the [project FAQ](http://dhalperi.github.com/linux-80211n-csitool/faq.html) for licensing information.
